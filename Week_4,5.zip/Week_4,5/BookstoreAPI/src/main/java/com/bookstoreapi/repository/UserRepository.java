package com.bookstoreapi.repository;

import com.bookstoreapi.model.Appuser;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserRepository extends JpaRepository<Appuser, Long> {
    Optional<Appuser> findByUsername(String username);
}
